By Using CommondLiner user can do the below operations.

1. Add Person (id, firstName, surname)
2. Edit Person (firstName, surname)
3. Delete Person (id)
4. Count Number of Persons
5. List Persons

Swagger URL:
http://localhost:8081/swagger-ui.html
1. Ability to Add Person from JSON by using the POSTMAN OR Above Swagger UI
2. Test coverage - Fully covered in TestEmployeeRepository.java
3. Maven  Build
4. Executable Jar 
Commmand to execute the jar
--------------
<drive>:\>cd <jar placed path>\java -jar springBootEmployeeRestServices-0.0.1-SNAPSHOT.jar

H2 Database 

http://localhost:8081/h2-console
