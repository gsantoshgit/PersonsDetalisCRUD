package com.gs.demo.employee.exceptions;

public class EmployeeObjExecptions extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public EmployeeObjExecptions(){
		
	}
	public EmployeeObjExecptions(final String message){
			super(message);
		
	}
}
